package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FilmActivity extends AppCompatActivity {

    private Button rButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film);
        rButton=findViewById(R.id.btn3);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //return
                Intent intent=new Intent(FilmActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        rButton=findViewById(R.id.btn4);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent=new Intent(FilmActivity.this,FilmActivity.class);
                startActivity(intent);
            }
        });



        rButton=findViewById(R.id.fB0);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent=new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton=findViewById(R.id.fB1);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent=new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton=findViewById(R.id.fB2);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent=new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton=findViewById(R.id.fB3);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent=new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton=findViewById(R.id.fB4);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent=new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });
    }
}
