package com.example.myapplication.data;

import android.util.Log;

import com.example.myapplication.data.model.LoggedInUser;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    public Result<LoggedInUser> login(final String username, final String password) {
        final String url = "http://106.12.203.34:8080/login";
        final String[] user = {"none"};
        final boolean[] flag = {false};
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    OkHttpClient okHttpClient = new OkHttpClient();
                    RequestBody body = new FormBody.Builder()
                            .add("username", username)
                            .add("password", password)
                            .build();
                    Request request = new Request.Builder()
                            .url(url)
                            .post(body)//默认就是GET请求
                            .build();
                    Response response = okHttpClient.newCall(request).execute();
                    String response_string = response.body().string();
                    Log.e("response ", response_string);
                    try {
                        JSONObject connect = new JSONObject(response_string);
                        if (connect.has("user")) {
                            Log.e("log in ", "succussful");
                            JSONObject userinfo = new JSONObject(connect.get("user").toString());
                            user[0] = userinfo.get("username").toString();
                            flag[0] = true;
                        } else {
                            Log.e("log in", "failed");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e("Json", "failed");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        t.start();
        try {
            //等待链接进程结束
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            // TODO: handle loggedInUser authentication
            if (flag[0]) {
                LoggedInUser fakeUser =
                        new LoggedInUser(
                                java.util.UUID.randomUUID().toString(),
                                user[0]);
                return new Result.Success<>(fakeUser);
            } else {
                return new Result.Failare<>(new LoggedInUser(java.util.UUID.randomUUID().toString(),username));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public void logout() {
        // TODO: revoke authentication
    }
}
