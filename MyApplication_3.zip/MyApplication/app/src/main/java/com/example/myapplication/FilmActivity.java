package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FilmActivity extends AppCompatActivity {

    private static Object lockObject = new Object();
    private Button rButton;
    //计划使用一个按钮的list来动态管理所有按钮
    private Button[] ButtonList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film);
        rButton = findViewById(R.id.btn3);
        String json = new String();
        String name = "none";
        //解析数据
        try {
            json = getName();
            JSONArray array = new JSONArray(json);
            JSONObject object = array.getJSONObject(0);
            name = object.get("name").toString();
        }catch (Exception e){
            e.printStackTrace();
        }
        TextView view = findViewById(R.id.tv);
        view.setText(name);
        final String finalJson = json;
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //return
                Intent intent = new Intent(FilmActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        rButton = findViewById(R.id.btn4);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmActivity.class);
                startActivity(intent);
            }
        });


        rButton = findViewById(R.id.fB0);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                intent.putExtra("json", finalJson);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB1);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB2);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB3);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB4);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });
    }


//获取数据的函数，其实主要是把电影名字get到就行
    private String getName(){
        final String[] res = {"name"};
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    //现阶段还是使用movies来把所有电影展示出来，有点不符合常理，未来考虑使用排片表screenings来获取当日所有影片名字信息
                    URL url = new URL("http://106.12.203.34:8080/movies");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream in = connection.getInputStream();
                    //下面对获取到的输入流进行读取
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    String Json = response.toString();
                    res[0] = Json;

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        });
        t.start();
        try {
            //等待链接进程结束
            t.join();
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        return res[0];
    }
}
