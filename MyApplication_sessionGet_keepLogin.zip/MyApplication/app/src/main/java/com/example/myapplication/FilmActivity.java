package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.myapplication.ui.login.LoginActivity;

import org.json.JSONArray;
import org.json.JSONObject;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FilmActivity extends AppCompatActivity {

    private static Object lockObject = new Object();
    private Button rButton;
    //计划使用一个按钮的list来动态管理所有按钮
    private Button[] ButtonList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film);
        rButton = findViewById(R.id.btn3);
        String json = new String();
        String name = "none";
        SharedPreferences sharedPreferences = getSharedPreferences("login",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String cookie = sharedPreferences.getString("session","");
        //解析数据
        try {
            json = getName();
            JSONArray array = new JSONArray(json);
            JSONObject object = array.getJSONObject(0);
            name = object.get("name").toString();
        }catch (Exception e){
            e.printStackTrace();
        }
        TextView view = findViewById(R.id.tv);
        view.setText(name);
        final String finalJson = json;
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //return
                Intent intent = new Intent(FilmActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        rButton = findViewById(R.id.btn4);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmActivity.class);
                startActivity(intent);
            }
        });


        rButton = findViewById(R.id.fB0);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                //暂时设定注销登录在这里，以免一直处于登录状态无法注销
                editor.clear();
                editor.commit();
                intent.putExtra("json", finalJson);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB1);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB2);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB3);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB4);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });
    }


//获取数据的函数，其实主要是把电影名字get到就行
private String getName(){
    final String url = "http://106.12.203.34:8080/movies";
    final String[] res = {"name"};
    Thread t = new Thread(new Runnable() {
        @Override
        public void run() {
            Log.e("now","in new thread");
            try {
                OkHttpClient okHttpClient = new OkHttpClient();
                final Request request = new Request.Builder()
                        .url(url)
                        .get()//默认就是GET请求
                        .build();
                Call call = okHttpClient.newCall(request);
                Response response = call.execute();
                String result = response.body().string();
                res[0]=result;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    });
    t.start();
    try {
        //等待链接进程结束
        t.join();
    }catch (InterruptedException e){
        e.printStackTrace();
    }
    return res[0];
}
}
