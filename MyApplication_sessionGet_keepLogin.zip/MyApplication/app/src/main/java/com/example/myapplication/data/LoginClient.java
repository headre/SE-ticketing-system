package com.example.myapplication.data;

import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class LoginClient {
    private OkHttpClient okHttpClient = new OkHttpClient();
    private String url = "http://106.12.203.34:8080/", result = "",cookie="";
    public void LoginClient() {
        this.url = "http://106.12.203.34:8080/";
    }

    private void ResetUrl() {
        this.url = "http://106.12.203.34:8080/";
    }

    public String getResult() {
        return result;
    }
    public String getCookie() {
        if(cookie==null||cookie==""){
            return "cookie is empty";
        }
        return cookie;
    }

    public void printResult(){
        Log.e("result is ", result);
    }
    public void setMode(String mode, String username, String password) {
        switch (mode) {
            case "movies":
                url += "movies";
                getMovies();
                ResetUrl();
                break;
            case "login":
                url += "login";
                login(username, password);
                ResetUrl();
                break;
            case "screenings":
                url += "screenings";
                ResetUrl();
                break;
        }
    }

    private void getMovies() {
        okHttpClient = new OkHttpClient();
        final Request request = new Request.Builder()
                .url(url)
                .get()//默认就是GET请求
                .build();
        Call call = okHttpClient.newCall(request);
        try {
            result = readMovJ(call);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String readMovJ(Call call) throws IOException {
        Response response = call.execute();
        return response.body().string();
    }

    public void login(String username, String password) {
        okHttpClient = new OkHttpClient.Builder().cookieJar(new CookieJar() {
            private final HashMap<HttpUrl, List<Cookie>> cookieStore = new HashMap<>();

            @Override
            public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                cookieStore.put(url, cookies);
                cookie = cookies.get(0).value();
            }

            @Override
            public List<Cookie> loadForRequest(HttpUrl url) {
                List<Cookie> cookies = cookieStore.get(HttpUrl.parse("http://106.12.203.34:8080/"));
                return cookies != null ? cookies : new ArrayList<Cookie>();
            }
        }).build();
        RequestBody body = new FormBody.Builder()
                .add("username", username)
                .add("password", password)
                .build();
        Request request = new Request.Builder()
                .url(url)
                .post(body)//默认就是GET请求
                .build();
        Call call = okHttpClient.newCall(request);
        try{
            Response response = call.execute();
            result = response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //尝试使用enqueue来进行异步处理，但好像我要的是同步处理
        /**call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("post","failed");
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                result = response.body().string();
                System.out.println("result is"+result);
            }
        });*/
    }
}
