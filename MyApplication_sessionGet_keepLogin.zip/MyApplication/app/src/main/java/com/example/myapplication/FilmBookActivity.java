package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class FilmBookActivity extends AppCompatActivity {
    private Button b_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_book);
        String json = "";
        String date = "no date available";
        String time = "no time available";
        String screen = "no screen available";
        String name = "no name get";
        String blurb="no blurb get";
        String director="no director get";
        String leadActors = "no leadActors get";
        b_button=findViewById(R.id.go_book_button0);
        b_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //jump to films
                Intent intent=new Intent(FilmBookActivity.this, FilmBookDetailActivity.class);
                startActivity(intent);
            }
        });
        try{
            json = getIntent().getStringExtra("json");
            JSONArray jsonArray = new JSONArray(json);
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            name = jsonObject.get("name").toString();
            blurb = jsonObject.get("blurb").toString();
            director = jsonObject.get("director").toString();
            leadActors = jsonObject.get("leadActors").toString();
            //获取排片
            JSONArray screeninglist = (JSONArray)jsonObject.getJSONArray("screeningList");
            JSONObject screening = screeninglist.getJSONObject(0);
            date = screening.get("date").toString();
            time = screening.get("time").toString();
            screen = screening.get("cinemaScreen").toString();
        }catch (Exception e){
            Log.e("error in","get Extra");
            e.printStackTrace();
        }
        b_button=findViewById(R.id.book_btn0);
        b_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //return
                Intent intent=new Intent(FilmBookActivity.this,FilmActivity.class);
                startActivity(intent);
            }
        });


        b_button=findViewById(R.id.book_btn1);
        b_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //return
                Intent intent=new Intent(FilmBookActivity.this,FilmBookActivity.class);
                startActivity(intent);
            }
        });

        // 设置显示更改ui
        TextView Mname = findViewById(R.id.fB_3);
        Mname.setText(name);
        TextView Mblurb = findViewById(R.id.bl_1);
        Mblurb.setText(blurb);
        Mblurb.append("...");

        TextView Mdirt = findViewById(R.id.dir_1);
        Mdirt.setText(director);

        TextView MAct = findViewById(R.id.act_2);
        MAct.setText(leadActors);

        TextView MScreen = findViewById(R.id.screening_1);
        MScreen.setText(date+"\n");
        MScreen.append(time+"\n");
        MScreen.append("cinemaScreen: "+screen);
    }
}

