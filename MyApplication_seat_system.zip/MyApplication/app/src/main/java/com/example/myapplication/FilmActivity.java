package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.myapplication.data.OkClient;
import com.example.myapplication.ui.login.LoginActivity;
import com.example.myapplication.data.ResolveJson;

import org.json.JSONArray;
import org.json.JSONObject;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FilmActivity extends AppCompatActivity {

    private static Object lockObject = new Object();
    private Button rButton;
    //计划使用一个按钮的list来动态管理所有按钮
    private Button[] ButtonList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film);
        rButton = findViewById(R.id.btn3);
        String json = "";
        String name = "none";
        SharedPreferences sharedPreferences = getSharedPreferences("login", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String cookie = sharedPreferences.getString("session", "");
        //解析数据
        try {
            json = getScreenings();
            Log.e("json",json);
            JSONArray array = new JSONArray(json);
            JSONObject object = array.getJSONObject(0);

            Log.e("content",object.get("movieId").toString());
            json = getMovie(object.get("movieId").toString());

            ResolveJson resolveJson = new ResolveJson(json);
            resolveJson.readSingleMovieName();
            name = resolveJson.getResult();
            if(!name.equals("The Seven Samurai")){
                Log.e("not","same");
            }else {
                Log.e("it","same");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        TextView view = findViewById(R.id.tv);
        view.setText(name);
        final String finalJson = json;
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //return
                Intent intent = new Intent(FilmActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        rButton = findViewById(R.id.btn4);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmActivity.class);
                startActivity(intent);
            }
        });


        rButton = findViewById(R.id.fB0);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                //暂时设定注销登录在这里，以免一直处于登录状态无法注销
                editor.clear();
                editor.commit();
                intent.putExtra("json", finalJson);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB1);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB2);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB3);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });

        rButton = findViewById(R.id.fB4);
        rButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this
                Intent intent = new Intent(FilmActivity.this, FilmBookActivity.class);
                startActivity(intent);
            }
        });
    }


    //获取数据的函数，其实主要是把电影名字get到就行
    private String getScreenings() {
        final String[] res = {"screenings"};
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                Log.e("now", "in new thread screening");
                try {
                    OkClient OkClient = new OkClient();
                    OkClient.setMode("screenings");
                    String result = OkClient.getResult();
                    res[0] = result;
                    Log.e("screen",res[0]);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        t.start();
        try {
            //等待链接进程结束
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return res[0];
    }
    private String getMovie(String id) {
        final String[] res = {"movie"};
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                Log.e("now", "in new thread");
                try {
                    OkClient OkClient = new OkClient();
                    OkClient.setMode("movies", id);
                    String result = OkClient.getResult();
                    Log.e("result",result);
                    res[0] = result;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        t.start();
        try {
            //等待链接进程结束
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return res[0];
    }
}
